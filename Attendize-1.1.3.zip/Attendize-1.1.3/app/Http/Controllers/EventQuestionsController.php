<?php

namespace App\Http\Controllers;

/* Depreciated */

class EventQuestionsController extends MyBaseController
{

}