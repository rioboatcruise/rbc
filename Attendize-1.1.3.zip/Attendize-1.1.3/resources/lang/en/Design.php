<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:21:50 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  'event_page_preview' => 'Event Page Preview',
  //==================================== Translations ====================================//
  'background_options' => 'Background Options',
  'images_provided_by_pixabay' => 'Images Provided By <b>PixaBay.com</b>',
  'select_from_available_images' => 'Select From Available Images',
  'use_a_colour_for_the_background' => 'Use a colour for the background',
);