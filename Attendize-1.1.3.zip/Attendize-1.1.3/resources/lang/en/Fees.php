<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 17:24:53 
*************************************************************************/

return array (
  'service_fee_fixed_price' => 'Service Fee Fixed Price',
  'service_fee_fixed_price_help' => 'e.g: enter <b>1.25</b> for <b>:cur1.25</b>',
  'service_fee_fixed_price_placeholder' => '0.00',
  'organiser_fees' => 'Organiser Fees',
  'organiser_fees_text' => 'These are optional fees you can include in the cost of each ticket. This charge will appear on buyer\'s invoices as \'<b>BOOKING FEES</b>\'.',
  'service_fee_percentage' => 'Service Fee Percentage',
  'service_fee_percentage_help' => 'e.g: enter <b>3.5</b> for <b>3.5%</b>',
  'service_fee_percentage_placeholder' => '0',
);