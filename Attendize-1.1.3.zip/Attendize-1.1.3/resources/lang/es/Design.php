<?php

return array(
    'event_page_preview'              => 'Vista previa de la página del evento',
    'background_options'              => 'Opciones de fondo',
    'images_provided_by_pixabay'      => 'Imágenes proporcionadas por <b>PixaBay.com</b>',
    'select_from_available_images'    => 'Selecciona de entre las imágenes disponibles',
    'use_a_colour_for_the_background' => 'Usa un color para el fondo',
);