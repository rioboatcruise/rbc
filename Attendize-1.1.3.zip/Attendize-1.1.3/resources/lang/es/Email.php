<?php

return array(
    'attendize_register'      => 'Gracias por registrarte en Attendize',
    'invite_user'             => ':name te ha añadido a la cuenta :app.',
    'message_regarding_event' => 'Mensaje con respecto a: :event',
    'organiser_copy'          => '[Copia del organizador]',
    'refund_from_name'        => 'Has recibido un reembolso de :name',
    'your_ticket_cancelled'   => 'Tu entrada ha sido cancelada',
    'your_ticket_for_event'   => 'Tu entrada para el evento :event',
    'LLH:obsolete'            => array(),
);
