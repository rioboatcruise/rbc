<?php

return array(
    'service_fee_fixed_price'             => 'Tarifa de servicio Precio fijo',
    'service_fee_fixed_price_help'        => 'p. ej.: introduce <b>1,25</b> para <b>1,25:cur</b>',
    'service_fee_fixed_price_placeholder' => '0.00',
    'organiser_fees'                      => 'Gastos de gestión',
    'organiser_fees_text'                 => 'Estos son cargos opcionales que puedes incluir en el coste de cada entrada. Este cargo aparecerá en las facturas del comprador como \'<b>Gastos de gestión</b>\'.',
    'service_fee_percentage'              => 'Porcentaje de los gastos de gestión',
    'service_fee_percentage_help'         => 'p.ej.: introduzca <b>3,5</b> para <b>3,5%</b>',
    'service_fee_percentage_placeholder'  => '0',
);