<?php

return array(
    'all_event_attendees'             => 'Todos los asistentes al evento',
    'attendees_with_ticket_type'      => 'Asistentes con tipo de entrada',
    'before_send_message'             => 'El asistente recibirá instrucciones para enviar cualquier respuesta a :organiser',
    'content'                         => 'Contenido del mensaje',
    'date'                            => 'fecha',
    'leave_blank_to_send_immediately' => 'Deja en blanco para enviar inmediatamente',
    'message'                         => 'Mensaje',
    'new_message'                     => 'Nuevo mensaje',
    'no_messages_for_event'           => 'No hay mensajes para el evento.',
    'schedule_send_time'              => 'Programar la hora de envío',
    'send_a_copy_to'                  => 'Enviar una copia a :organiser',
    'send_message'                    => 'Enviar Mensaje',
    'send_to'                         => 'Enviar a',
    'sent_messages'                   => 'Mensajes enviados',
    'subject'                         => 'Asunto del mensaje',
    'to'                              => 'A',
    'unsent'                          => 'No enviado',
);