<?php

return array(
    'add_question'          => 'Agregar pregunta',
    'answers'               => 'Respuestas',
    'event_surveys'         => 'Encuestas del evento',
    'export_answers'        => 'Exportar respuestas',
    'num_responses'         => 'Nº de Respuestas',
    'question_delete'       => 'Eliminar Pregunta',
    'question_delete_title' => 'Todas las respuestas también serán eliminadas. Si deseas mantener las respuestas de los asistentes, deberías desactivar la pregunta en su lugar.',
    'question_title'        => 'Título de la pregunta',
    'required'              => 'Requerido',
    'status'                => 'Estado',
    'tickets_list'          => 'Entradas: :list',
);