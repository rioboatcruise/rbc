<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/19 18:57:21 
*************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    'this_event_has_started' => 'Cet événement a commencé',
    //==================================== Translations ====================================//
    'create_tickets' => 'Créer des billets',
    'edit_event_page_design' => 'Éditer le design de la page événement',
    'edit_organiser_fees' => 'Éditer les frais de l\'organisateur',
    'event_page_visits' => 'Vues de la page d\'événement',
    'event_url' => 'URL de l\'événement',
    'event_views' => 'Vues de l\'événement',
    'generate_affiliate_link' => 'Générer un lien d\'affiliation',
    'orders' => 'Commandes',
    'quick_links' => 'Liens rapides',
    'registrations_by_ticket' => 'Enregistrements par billet',
    'sales_volume' => 'Volume de ventes',
    'share_event' => 'Partager l\'événement',
    'this_event_is_on_now' => 'Cet événement est désormais actif',
    'ticket_sales_volume' => 'Volume des ventes de billet',
    'tickets_sold' => 'Billets vendus',
    'website_embed_code' => 'Code d\'intégration pour site web',
);
