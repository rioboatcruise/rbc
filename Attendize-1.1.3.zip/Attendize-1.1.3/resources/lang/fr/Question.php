<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/18 16:23:42 
*************************************************************************/

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Partials\\SurveyBlankSlate.blade.php
  'create_question' => 'Créer une question',
  //==================================== Translations ====================================//
  'Q' => 'Q',
  'add_another_option' => 'Ajouter une autre option',
  'answer' => 'Répondre',
  'attendee_details' => 'Détail du participant',
  'make_this_a_required_question' => 'Rendre cette option requise',
  'no_answers' => 'Désolé, il n\'y a pas encore de réponse à cette question.',
  'no_questions_yet' => 'Pas encore de question',
  'no_questions_yet_text' => 'Ici vous pouvez ajouter des questions qui seront posées aux participants pendant leur procédure de réservation.',
  'question' => 'Question',
  'question_options' => 'Options de la question',
  'question_placeholder' => 'par ex. Merci de saisir votre adresse complète ?',
  'question_type' => 'Type de question',
  'require_this_question_for_ticket(s)' => 'Exiger une réponse pour le(s) billet(s)',
);
