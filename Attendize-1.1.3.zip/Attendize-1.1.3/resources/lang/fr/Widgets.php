<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Widgets.blade.php
  'embed_preview' => 'Prévisualisation',
  //==================================== Translations ====================================//
  'event_widgets' => 'Widgets d\'événement',
  'html_embed_code' => 'code HTML d\'encapsulation',
  'instructions' => 'Mode d\'emploi',
  'instructions_text' => 'Copier et coller le code HTML fourni à l\'endroit où vous souhaitez faire apparaître le widget.',
);
