<?php

return [
    'back_soon' => 'Nous revenons bientôt',
    'back_soon_description'     => 'Nous sommes en train d\'améliorer notre site web.',

];
