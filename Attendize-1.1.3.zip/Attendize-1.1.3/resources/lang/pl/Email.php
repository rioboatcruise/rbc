<?php
/*************************************************************************
 Generated via "php artisan localization:missing" at 2018/04/26 11:05:24 
*************************************************************************/

return array (
  //==================================== Translations ====================================//
  'attendize_register' => 'Dziękujemy za rejestrację w Attendize',
  'invite_user' => ':name dodał cię do konta :app.',
  'message_regarding_event' => 'Wiadomość w związku z: :event',
  'organiser_copy' => '[Kopia Organizatora]',
  'refund_from_name' => 'Otrzymaleś refundację od :name',
  'your_ticket_cancelled' => 'Twój bilet został anulowany',
  'your_ticket_for_event' => 'Twój bilet na wydarzenie :event',
  //================================== Obsolete strings ==================================//
  'LLH:obsolete' => 
  array (

  ),
);
