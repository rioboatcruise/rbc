<?php

return array (
  'new_message' => 'Nowa Wiadomość',
  'sent_messages' => 'Wysłane Wiadomości',
  'all_event_attendees' => 'Wszyscy członkowie wydarzenia',
  'attendees_with_ticket_type' => 'Uczestnicy z biletem',
  'before_send_message' => 'Uczestnik zostanie poinstruowany o możliwości odpowiedzi na adres :organiser',
  'content' => 'Treść wiadomości',
  'date' => 'data',
  'leave_blank_to_send_immediately' => 'Pozostaw puste, aby wysłać teraz',
  'message' => 'Wiadomość',
  'no_messages_for_event' => 'Brak wiadomości związanych z tym wydarzeniem.',
  'schedule_send_time' => 'Wyslij później',
  'send_a_copy_to' => 'Wyślij kopię do :organiser',
  'send_message' => 'Wyślij wiadomość',
  'send_to' => 'Wyślij do',
  'subject' => 'Temat',
  'to' => 'Do',
  'unsent' => 'Nie wysłano',
);