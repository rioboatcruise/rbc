<?php

return array (
  //============================== New strings to translate ==============================//
  // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\ManageEvent\\Surveys.blade.php
  'question_delete' => 'Usuń pytanie',
  //==================================== Translations ====================================//
  'add_question' => 'Dodaj Pytanie',
  'answers' => 'Odpowiedzi',
  'event_surveys' => 'Kwestionariusz Wydarzenia',
  'export_answers' => 'Eksportuj odpowiedzi',
  'num_responses' => '# Odpowiedzi',
  'question_delete_title' => 'Wszystkie odpowiedzi zostaną usunięte. Jeżeli chcesz zachować odpowiedzi uczestników, zamiast tego deaktywuj pytanie.',
  'question_title' => 'Tytuł Pytania', // ???
  'required' => 'Wymagane',
  'status' => 'Status',
  'tickets_list' => 'Bilety: :list',
);