<?php
/*************************************************************************
Generated via "php artisan localization:missing" at 2018/04/25 10:00:32
 *************************************************************************/

return array (
    //============================== New strings to translate ==============================//
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
    'account_settings' => 'Ustawienia Konta',
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
    'create_organiser' => 'Utwórz Organizatora',
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
    'feedback_bug_report' => 'Wsparcie / Raporty (EN)',
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
    'my_profile' => 'Mój Profil',
    // Defined in file C:\\wamp\\www\\attendize\\resources\\views\\Shared\\Layouts\\Master.blade.php
    'sign_out' => 'Wyloguj się',
);