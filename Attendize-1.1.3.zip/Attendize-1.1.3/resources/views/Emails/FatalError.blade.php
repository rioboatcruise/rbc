<p>
    {{json_encode($exception)}}
</p>
