@extends('en.Emails.Layouts.Master')

@section('message_content')
Hello,<br><br>

Your email was sent successfully.

<br><br>
Thank you
@stop
