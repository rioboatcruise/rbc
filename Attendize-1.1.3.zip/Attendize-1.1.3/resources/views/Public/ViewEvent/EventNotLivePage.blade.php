@extends('Shared.Layouts.MasterWithoutMenus')

@section('title')
    Event Not Live
@stop

@section('content')
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel">
                <div class="panel-body">
                    <h4 style="text-align: center;">@lang("Public_ViewEvent.event_not_live")</h4>
                </div>
            </div>
        </div>
    </div>
@stop