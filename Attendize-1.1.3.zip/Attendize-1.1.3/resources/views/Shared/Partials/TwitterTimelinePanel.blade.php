<div class="panel mt10">
    <a class="twitter-timeline" data-height="400" href="https://twitter.com/{{ $twitter_account }}">Tweets by {{ $twitter_account }}</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>

